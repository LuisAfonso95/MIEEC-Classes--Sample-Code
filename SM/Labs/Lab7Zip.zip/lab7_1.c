#include <stdio.h>

int main(){
 int k=7;
 printf("Lab %d \n",k);
}
