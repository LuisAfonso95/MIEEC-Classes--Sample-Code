void bin_img(unsigned char *ptr, int w, int h, unsigned char limiar)
{
/* ... */
}