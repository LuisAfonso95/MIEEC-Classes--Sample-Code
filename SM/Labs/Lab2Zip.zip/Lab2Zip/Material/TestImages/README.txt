Estamos a trabalhar com imagens .pgm, que é um formato de imagem como o .jpeg, ou o .bmp. Para ler este tipo de imagems use os seguintes programas que estão disponíveis gratuitamente:

Windows: IrfanView
MACOSX: ToyViewer
Linux: Gimp ou xv


